
ptop - v3 coco
==============================

This dataset was exported via roboflow.ai on November 26, 2021 at 4:57 AM GMT

It includes 10 images.
Object are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


